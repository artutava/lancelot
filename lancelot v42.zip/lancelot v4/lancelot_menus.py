import bpy

from bpy.types import Menu, Operator

class PIE_MT_IkFingersMenu(Menu):
    """Pie Menu for IK Fingers"""
    bl_label = "IK Fingers Menu"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()

        # Left Option: IK Fingers L
        pie.operator("object.select_bone_collection", text="IK Fingers L").collection_name = "IK Fingers L"
        
        # Right Option: IK Fingers R
        pie.operator("object.select_bone_collection", text="IK Fingers R").collection_name = "IK Fingers R"